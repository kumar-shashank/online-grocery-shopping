<footer>
<p>&copy 2019 . All Rights Reserved | Design by Shashank Kumar </p>
</footer>
